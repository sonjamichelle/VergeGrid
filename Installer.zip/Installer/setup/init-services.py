#!/usr/bin/env python3
# ==========================================================
# VergeGrid Service Initializer
# init-services.py
# ----------------------------------------------------------
# Registers and starts VergeGrid Windows services.
# Requires admin privileges.
# ==========================================================

import subprocess
import logging
import sys
from pathlib import Path

# ----------------------------------------------------------
# LOGGING CONFIGURATION
# ----------------------------------------------------------
LOG_PATH = Path.home() / "vergegrid_service_init.log"
logging.basicConfig(
    filename=LOG_PATH,
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)

# ----------------------------------------------------------
# SERVICE DEFINITIONS
# ----------------------------------------------------------
SERVICES = {
    "VergeGridCore": {
        "display_name": "VergeGrid Core Service",
        "exe_path": r"C:\VergeGrid\core_service.exe"
    },
    "VergeGridWorker": {
        "display_name": "VergeGrid Worker Node",
        "exe_path": r"C:\VergeGrid\worker_service.exe"
    }
}

# ----------------------------------------------------------
# HELPER FUNCTIONS
# ----------------------------------------------------------
def run_cmd(cmd):
    """Run a shell command and return (exit_code, stdout, stderr)."""
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return result.returncode, result.stdout.strip(), result.stderr.strip()

def service_exists(name):
    """Check if a Windows service already exists."""
    code, out, _ = run_cmd(f'sc query "{name}"')
    return "FAILED 1060" not in out  # 1060 = The specified service does not exist

def create_service(name, config):
    """Create a Windows service using 'sc create'."""
    exe = config["exe_path"]
    if not Path(exe).exists():
        logging.error(f"Executable not found for {name}: {exe}")
        return False
    
    cmd = (
        f'sc create "{name}" binPath= "{exe}" '
        f'DisplayName= "{config["display_name"]}" start= auto'
    )
    code, out, err = run_cmd(cmd)
    if code == 0:
        logging.info(f"Created service '{name}' successfully.")
        return True
    else:
        logging.error(f"Failed to create service '{name}': {out or err}")
        return False

def start_service(name):
    """Start a Windows service if not already running."""
    code, out, _ = run_cmd(f'sc query "{name}"')
    if "RUNNING" in out:
        logging.info(f"Service '{name}' already running.")
        return True

    code, out, err = run_cmd(f'sc start "{name}"')
    if code == 0:
        logging.info(f"Service '{name}' started successfully.")
        return True
    else:
        logging.error(f"Failed to start service '{name}': {out or err}")
        return False

# ----------------------------------------------------------
# MAIN EXECUTION LOGIC
# ----------------------------------------------------------
def main():
    logging.info("========== VergeGrid Service Initialization ==========")
    
    # Check for admin rights (naive check)
    code, _, _ = run_cmd("net session")
    if code != 0:
        print("⚠️  This script must be run as Administrator.")
        logging.error("Script requires administrative privileges.")
        sys.exit(1)

    for name, config in SERVICES.items():
        logging.info(f"Processing service: {name}")
        
        if service_exists(name):
            logging.info(f"Service '{name}' already exists. Skipping creation.")
        else:
            if not create_service(name, config):
                print(f"❌ Failed to create {name}. See log: {LOG_PATH}")
                sys.exit(1)

        if not start_service(name):
            print(f"⚠️ Could not start service '{name}'. Check logs.")
        else:
            print(f"✅ Service '{name}' is active.")

    logging.info("All services processed successfully.")
    print(f"\nInitialization complete. Log saved to: {LOG_PATH}")

# ----------------------------------------------------------
# ENTRY POINT
# ----------------------------------------------------------
if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logging.exception(f"Unexpected error: {e}")
        print(f"❌ Initialization failed: {e}")
        sys.exit(1)
