==================================================

INSTALLATION.md

Installation Guide (Placeholder)

This file will contain the complete installation instructions for VergeGrid once the installer and bootstrap system reach their first stable milestone.

Planned sections:

System Requirements

Pre-Installation Checklist

Running the VergeGrid Installer

Database Setup

Region and Estate Auto-Creation

Starting Robust and OpenSim

Configuring the Admin Web UI

Enabling GloBits

Viewer Setup

Troubleshooting

This document will be expanded as the installer reaches functionality milestones.

==================================================